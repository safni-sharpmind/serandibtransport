<?php include ('inc/header.php'); ?>

<section class="page-title page-title-layout1 bg-overlay bg-overlay-2 bg-parallax">
    <div class="bg-img"><img src="assets/images/page-titles/1.jpg" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                <!-- <span class="pagetitle__subheading">World's Leading Industry Corporation!</span> -->
                <h1 class="pagetitle__heading">Our Special Services</h1>
                <!-- <a href="projects-grid.html" class="btn btn__white btn__bordered btn__icon">
                    <span>Latest Projects</span><i class="icon-arrow-right"></i>
                </a> -->
            </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.page-title -->


<!--================ Start Course Details Area =================-->
<section style="background-color: #1E1E1E;" class="course-details-area section-gap">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <img class="img-fluid" src="assets/images/1.jpg" alt="" />
            </div>
            <div class="col-md-7 mt-sm-20">
                <h4 style="color:white;">Reliable Loading and Unloading Services</h4>
                <br>
                <p>Looking for reliable and efficient loading and unloading services? Look no further! We specialize in
                    loading and unloading 20ft and 40ft containers, as well as flatbed trucks, to help businesses
                    transport their goods safely and efficiently to different locations.</p>

                <p>Our team of professionals carefully plans the loading process to ensure the weight and size of the
                    cargo is evenly distributed, preventing damage to the container or the goods during transport. With
                    our specialized equipment, such as cranes and forklifts, we ensure that the cargo is handled safely
                    and efficiently during unloading.</p>
            </div>
        </div>
        <br><br>
        <div class="row flex-reverse">
            <div class="col-md-7">
                <h4 style="color:white;">Lifting and Unloading Services for Heavy Items
                </h4><br>
                <p class="text-left">We also provide specialized lifting and unloading services for heavy or bulky items
                    from tall buildings. Our experts thoroughly assess the building's architecture, safety features, and
                    the type of items to be moved before the lifting process begins.</p>
                <p class="text-left">We help businesses, construction companies, and individuals transport large items
                    such as furniture, machinery, construction materials, or heavy equipment to or from tall buildings.
                    Depending on the weight and size of the items, we use different types of lifting equipment and
                    strictly follow safety protocols to avoid accidents or property damage.</p>
            </div>
            <div class="col-md-5">
                <img src="assets/images/2.jpg" alt="" class="img-fluid">
            </div>
        </div>
        <br><br>



        <div class="row">
            <div class="col-md-5">
                <img class="img-fluid" src="assets/images/3.jpg" alt="" />
            </div>
            <div class="col-md-7 mt-sm-20">
                <h4 style="color:white;">Professional Machinery Placement Services</h4>
                <br>
                <p>At our company, we understand the importance of proper placement and installation of large machinery
                    in commercial and industrial settings. Our team of highly-trained professionals utilizes specialized
                    tools and equipment to ensure safe and efficient installation, taking into consideration all
                    relevant factors such as site assessment, measurements, and site engineer's method statement.</p>

                <p>We go the extra mile by ensuring timely and secure delivery of the equipment to the designated site.
                    Using state-of-the-art cranes, hoists, and rigging equipment, we ensure precise positioning and
                    secure installation of the machinery. We also make sure to connect the equipment to the relevant
                    systems, conduct thorough tests, and ensure compliance with local regulations and safety standards.
                </p>
            </div>
        </div>
        <br><br>
        <div class="row flex-reverse">
            <div class="col-md-7">
                <h4 style="color:white;">Safe and Efficient Transportation of Machinery
                </h4><br>
                <p class="text-left">Our team follows a comprehensive approach to ensure the safe and efficient
                    transportation and placement of various machinery. Starting with the assessment of transportation
                    requirements, we determine the best route, mode of transportation, and packaging to ensure secure
                    transit.</p>
                <p class="text-left">Upon arrival at the destination, our experts assess the site and determine the best
                    location for the equipment based on space requirements, access to utilities, and safety
                    considerations. We also unpack and assemble the equipment with specialized tools and high-level
                    expertise, ensuring safe and correct setup.</p>
            </div>
            <div class="col-md-5">
                <img src="assets/images/4.jpg" alt="" class="img-fluid">
            </div>
        </div>
        <br><br>
    </div>
</section>
<!--================ End Course Details Area =================-->

<?php include ('inc/footer.php'); ?>