<?php
function base_url($params = null)
{
    $whitelist = array('127.0.0.1', '::1');
    if (in_array($_SERVER['REMOTE_ADDR'], $whitelist))
        return $baseurl = 'https://serandibtransport.test/' . $params;
    return $baseurl = 'https://serandibtransport.lk/' . $params;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="description" content="Serandib Transport">
    <link href="assets/images/favicon/favicon.png" rel="icon">
    <title>Serandib Transport</title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Barlow:400,500,600,700%7cRoboto:400,500,700&display=swap">
    <link rel="stylesheet" href="assets/css/libraries.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body>
    <div class="wrapper">

        <!-- =========================
        Header
    =========================== -->
        <header class="header header-transparent header-layout1">
            <nav class="navbar navbar-expand-lg sticky-navbar">
                <div class="container-fluid">
                    <a class="navbar-brand" href="index.html">
                        <img src="assets/images/logo/serandib-logo.png" class="logo-light" alt="logo">
                        <img src="assets/images/logo/serandib-logo.png" class="logo-dark" alt="logo">
                    </a>
                    <button class="navbar-toggler" type="button">
                        <span class="menu-lines"><span></span></span>
                    </button>
                    <div class="collapse navbar-collapse" id="mainNavigation">
                        <ul class="navbar-nav">
                            <li class="nav__item">
                                <a href="<?= base_url('') ?>" class="nav__item-link active">Home</a>
                            </li><!-- /.nav-item -->
                            <li class="nav__item">
                                <a href="<?= base_url('services') ?>" class="nav__item-link">Services</a>
                            </li><!-- /.nav-item -->
                            <li class="nav__item">
                                <a href="<?= base_url('showcase') ?>" class="nav__item-link">Showcase</a>
                            </li><!-- /.nav-item -->
                            <li class="nav__item">
                                <a href="<?= base_url('about') ?>" class="nav__item-link">About</a>
                            </li><!-- /.nav-item -->
                            <li class="nav__item">
                                <a href="<?= base_url('contact') ?>" class="nav__item-link">Contact</a>
                            </li><!-- /.nav-item -->
                            <li class="nav__item nav__item-btn d-none d-md-block">
                                <a href="" class="btn btn__primary action__btn-request">
                                    <span>Get A Quote</span><i class="icon-arrow-right"></i>
                                </a>
                            </li>
                        </ul><!-- /.navbar-nav -->
                    </div><!-- /.navbar-collapse -->
                    <!-- <div class="contact__number d-flex align-items-center">
                        <i class="icon-phone"></i>
                        <a href="tel:5565454117">55 654 541 17</a>
                    </div> -->
                </div><!-- /.container -->
            </nav><!-- /.navabr -->
        </header><!-- /.Header -->