<?php

$to = 'info@serandibtransport.lk';
$name = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$subject = $_POST["subject"];
$message = $_POST["messgae"];

$subject = 'Contact Form Submission';

$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= "From: " . 'info@serandibtransport.lk' . "\r\n"; // Sender's E-mail
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$message = '<table style="width:100%">
        <tr><td>Name: ' . $name . '</td></tr>
        <tr><td>Email: ' . $email . '</td></tr>
        <tr><td>Phone Number: ' . $phone . '</td></tr>
        <tr><td>Subject: ' . $subject . '</td></tr>
        <tr><td>Message: ' . $message . '</td></tr>
    </table>';

if (@mail($to, $subject, $message, $headers)) {
    $redirectUrl = 'contact?message=success';
} else {
    $redirectUrl = 'contact?message=fail';
}

// Redirect to the specified URL
header("Location: $redirectUrl");

// Clear the message parameter from the URL
$redirectUrlWithoutMessage = strtok($redirectUrl, '?');
echo "<script>window.location.href='$redirectUrlWithoutMessage'</script>";

// Make sure that code execution stops here
exit();
?>