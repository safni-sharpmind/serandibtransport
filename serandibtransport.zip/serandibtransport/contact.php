<?php include ('inc/header.php'); ?>

<section class="page-title page-title-layout1 bg-overlay bg-overlay-2 bg-parallax">
    <div class="bg-img"><img src="assets/images/page-titles/1.jpg" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                <!-- <span class="pagetitle__subheading">World's Leading Industry Corporation!</span> -->
                <h1 class="pagetitle__heading">Contact Us</h1>
                <!-- <a href="projects-grid.html" class="btn btn__white btn__bordered btn__icon">
                    <span>Latest Projects</span><i class="icon-arrow-right"></i>
                </a> -->
            </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.page-title -->

<!-- ==========================
        contact layout 1
    =========================== -->
<section style="background-color: #1E1E1E;" class="contact-layout1 pt-0 pb-70">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div style="background-color: #1E1E1E;" class="contact-panel">
                    <div class="contact__panel-info">
                        <div class="contact__panel-info-top">
                            <div class="contact-info-box">
                                <h4 class="contact__info-box-title">Our Location</h4>
                                <ul class="contact__info-list list-unstyled">
                                    <li>2307 Beverley Rd Brooklyn, New York 11226 United States.</li>
                                </ul><!-- /.contact__info-list -->
                            </div><!-- /.contact-info-box -->
                            <div class="contact-info-box">
                                <h4 class="contact__info-box-title">Quick Contact</h4>
                                <ul class="contact__info-list list-unstyled">
                                    <li>Email: <a href="mailto:Promina@7oroof.com">Promina@7oroof.com</a></li>
                                    <li>Support: <a href="mailto:Promina@7oroof.com">Promina@7oroof.com</a></li>
                                </ul><!-- /.contact__info-list -->
                            </div><!-- /.contact-info-box -->
                        </div><!-- /.contact__panel-info-top -->
                        <div class="contact__panel-info-bottom">
                            <strong class="contact__panel-info-title">We will get back to you within 24 hours, or call
                                us
                                everyday, 09:00 AM - 12:00 PM</strong>
                            <div class="contact__number d-flex align-items-center">
                                <i class="icon-phone"></i>
                                <a href="tel:5565454117">55 654 541 17</a>
                            </div>
                        </div><!-- /.contact__panel-info-bottom -->
                    </div><!-- /.contact__panel-info -->
                    <form method="post" action="<?= base_url('contact-mail.php') ?>" class="contact__panel-form">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 style="color: #38b395;" class="contact__panel-title">Get In Touch</h4>
                                <p class="contact__panel-desc mb-40">Complete control over products allows us to ensure
                                    our
                                    customers receive the best quality prices and service. We take great pride in
                                    everything that we
                                    do in our factory.</p>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" id="contact-name"
                                        name="name" required>
                                </div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email" id="contact-email"
                                        name="email" required>
                                </div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Phone" id="contact-Phone"
                                        name="phone" required>
                                </div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Website" id="contact-subject"
                                        name="subject" required>
                                </div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Additional Details!"
                                        placeholder="Message" id="contact-messgae" name="messgae" required></textarea>
                                </div>
                            </div><!-- /.col-lg-12 -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <button type="submit" class="btn btn__primary btn__block  btn__lg">
                                    <span class="mx-2">Submit</span><i class="icon-arrow-right mx-2"></i>
                                </button>
                            </div><!-- /.col-lg-12 -->
                        </div><!-- /.row -->
                    </form>
                </div><!-- /.contact__panel -->
            </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.contact layout 1 -->

<!-- ==========================
       Contact Info
    ============================ -->
<section style="background-color: #1E1E1E;" class="contact-info pt-0 pb-70">
    <div class="container">
        <div class="row">
            <!-- Contact panel #1 -->
            <div class="col-sm-12 col-md-4 col-lg-4">
                <div class="contact-info-box">
                    <h4 style="color: #38b395;" class="contact__info-box-title">London Office</h4>
                    <ul class="contact__info-list list-unstyled">
                        <li>Email: <a href="mailto:Promina@7oroof.com">Promina@7oroof.com</a></li>
                        <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                        <li>Phone: <a href="tel:5565454117">55 654 541 17</a></li>
                        <li>Hours: Mon-Fri: 8am – 7pm</li>
                    </ul><!-- /.contact__info-list -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-lg-4 -->
            <!-- Contact panel #2 -->
            <div class="col-sm-12 col-md-4 col-lg-4">
                <div class="contact-info-box">
                    <h4 style="color: #38b395;" class="contact__info-box-title">Berlin Office</h4>
                    <ul class="contact__info-list list-unstyled">
                        <li>Email: <a href="mailto:Promina@7oroof.com">Promina@7oroof.com</a></li>
                        <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                        <li>Phone: <a href="tel:5565454117">55 654 541 17</a></li>
                        <li>Hours: Mon-Fri: 8am – 7pm</li>
                    </ul><!-- /.contact__info-list -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-lg-4 -->
            <!-- Contact panel #3 -->
            <div class="col-sm-12 col-md-4 col-lg-4">
                <div class="contact-info-box">
                    <h4 style="color: #38b395;" class="contact__info-box-title">Manchester Office</h4>
                    <ul class="contact__info-list list-unstyled">
                        <li>Email: <a href="mailto:Promina@7oroof.com">Promina@7oroof.com</a></li>
                        <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                        <li>Phone: <a href="tel:5565454117">55 654 541 17</a></li>
                        <li>Hours: Mon-Fri: 8am – 7pm</li>
                    </ul><!-- /.contact__info-list -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-lg-4 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.Contact Info -->


<section style="background-color: #1E1E1E;" class="google-map-layout2 p-0">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 ">
                <div id="map" style="height: 460px;"></div>
                <script src="assets/js/google-map.js"></script>
                <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async
                    defer></script>
                <!-- CLICK HERE (https://developers.google.com/maps/documentation/embed/get-api-key) TO  LERAN MORE ABOUT GOOGLE MAPS API KEY -->
            </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.GoogleMap -->


<?php
// Check if 'message' query parameter exists and has a value
$message = isset($_GET['message']) ? $_GET['message'] : '';

if ($message === 'fail'):
    ?>
    <script>
        swal("Error", "Form submission failed", "error");
        clearUrlParameter('message');
    </script>
<?php elseif ($message === 'success'): ?>
    <script>
        swal("Success", "Form submitted successfully", "success");
        clearUrlParameter('message');
    </script>
<?php endif; ?>

<script>
    function clearUrlParameter(parameterName) {
        var urlWithoutParameter = window.location.pathname + window.location.search.replace(new RegExp('[?&]' + parameterName + '=[^&#]*(#.*)?$'), '$1');
        window.history.replaceState({}, document.title, urlWithoutParameter);
    }
</script>

<?php include ('inc/footer.php'); ?>