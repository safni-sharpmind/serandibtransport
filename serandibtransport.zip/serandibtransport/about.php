<?php include ('inc/header.php'); ?>

<section class="page-title page-title-layout1 bg-overlay bg-overlay-2 bg-parallax">
    <div class="bg-img"><img src="assets/images/page-titles/1.jpg" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                <!-- <span class="pagetitle__subheading">World's Leading Industry Corporation!</span> -->
                <h1 class="pagetitle__heading">About Us</h1>
                <!-- <a href="projects-grid.html" class="btn btn__white btn__bordered btn__icon">
                    <span>Latest Projects</span><i class="icon-arrow-right"></i>
                </a> -->
            </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.page-title -->



<section style="background-color: #1E1E1E;" class="about-layout2">
    <div class="container-fluid">
        <div class="row">
            <div class="text-block">
                <div class="heading-layout2 mb-30">
                    <span class="heading__subtitle">THE INSPIRING STORY OF D G UPALI & SONS</span>
                    <!-- <h2 class="heading__title">Bigger, Better, Faster And Stronger Projects Than Ever!!</h2> -->
                    <p class="heading__desc mb-30 mt-40">In 1980, a young man named D.G.Upali Siriwardhana began his
                        journey in the logistics industry, working tirelessly for a logistics company. Despite his
                        dedication to his job, he always had a dream of starting his own logistics company someday. Over
                        the years, he worked hard to save up the necessary funds for vehicles and machinery, while
                        constantly learning and expanding his knowledge of the industry. Finally, in 1995, he took the
                        bold step of starting his own company, a sole proprietorship named D.U.A.Siriwardhana & Sons.
                    </p>
                    <p class="heading__desc">With unwavering courage and determination, D.G.Upali Siriwardhana and his
                        team quickly built a reputation for providing high-quality logistics services, earning the trust
                        and loyalty of customers across the country. In 2020, with the support and assistance of his
                        son, D.G.Udesh Nuwan Siriwardhana, the company underwent a major restructuring and was
                        transformed into a private limited company under the new name, D.G.Upali & Sons Private Limited.
                    </p>
                </div><!-- /heading -->
            </div><!-- /.col-xl-7 -->
            <div class="imgs-block mt-50">
                <div class="about__img">
                    <img src="assets/images/about/2.png" alt="about" class="img-fluid w-100">
                </div><!-- /.about-img -->
                <!-- <div class="video__box">
                    <h6 style="color:wheat; margin-top: 50px;">29+ Years of <br> working experience</h6>
                </div> -->
            </div><!-- /.col-xl-5 -->
        </div><!-- /.row -->
        <div style="margin-left: 70px; margin-top: 70px;" class="row">
            <div class="col-md-6">
                <h4 style="color:#38b395;">Our Mission</h4>
                <p>To provide reliable, efficient, and customer-focused solutions that keep your cargo moving safely and
                    on time. We're committed to doing it with the utmost care, transparency, and innovation while
                    prioritizing the safety of our employees, the environment, and the communities we serve.</p>
            </div>
            <div class="col-md-6">
                <h4 style="color:#38b395;">Our vision</h4>
                <p>To be the preferred logistics partner for businesses across industries, providing cost-effective
                    solutions that drive their growth & success</p>
            </div>
        </div>
    </div><!-- /.container -->
</section><!-- /.About Layout 2 -->


<?php include ('inc/footer.php'); ?>