<?php include 'inc/header.php' ?>


<!-- ============================
        Slider
    ============================== -->
<section class="slider slider-layout1">
    <div class="slick-carousel carousel-arrows-light m-slides-0"
        data-slick='{"slidesToShow": 1, "arrows": true, "dots": true, "speed": 700,"fade": true,"cssEase": "linear"}'>
        <div class="slide-item align-v-h bg-overlay bg-overlay-2">
            <div class="bg-img"><img src="assets/images/sliders/1.jpg" alt="slide img"></div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-9">
                        <div class="slide__content">
                            <h2 class="slide__title">Most trusted logistics & placement services</h2>
                            <!-- <p class="slide__desc">A leading developer of A-grade commercial, industrial and residential
                                projects
                                in USA. Since its foundation the company has doubled its turnover year on year, with its
                                staff
                                numbers swelling accordingly. </p> -->
                            <a href="#" class="btn btn__primary btn__icon btn__lg mr-30">
                                <span>Our Services</span><i class="icon-arrow-right"></i>
                            </a>
                            <a href="#" class="btn btn__white">Explore More</a>
                        </div><!-- /.slide-content -->
                    </div><!-- /.col-xl-9 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.slide-item -->
    </div><!-- /.carousel -->
</section><!-- /.slider -->

<!-- ==========================
       Contact Info
    ============================ -->
<section style="background-color: #1E1E1E;" class="contact-info-layout2 pt-60 pb-30 bg-color">
    <div class="container">
        <div class="row align-items-end">
            <!-- Contact panel #1 -->
            <div class="col-sm-12 col-md-6 col-lg-3">
                <div class="contact-info-box d-flex align-items-center">
                    <div class="contact__info-box-icon">
                        <i class="icon-envelope"></i>
                    </div>
                    <div class="contact__info-box-content">
                        <h4 style="color: wheat;" class="contact__info-box-title">Quick Contact</h4>
                        <ul class="contact__info-list list-unstyled">
                            <li>Email: <a href="mailto:Promina@7oroof.com">Promina@7oroof.com</a></li>
                            <li>Phone: <a href="tel:5565454117">55 654 541 17</a></li>
                        </ul><!-- /.contact__info-list -->
                    </div><!-- /.contact__info-box-content -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-lg-3 -->
            <!-- Contact panel #2 -->
            <div class="col-sm-12 col-md-6 col-lg-3">
                <div class="contact-info-box d-flex align-items-center">
                    <div class="contact__info-box-icon">
                        <i class="icon-location"></i>
                    </div>
                    <div class="contact__info-box-content">
                        <h4 style="color: wheat;" class="contact__info-box-title">Our Location</h4>
                        <ul class="contact__info-list list-unstyled">
                            <li>2307 Beverley Rd Brooklyn, New York 11226 US.</li>
                        </ul><!-- /.contact__info-list -->
                    </div><!-- /.contact__info-box-content -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-lg-3 -->
            <!-- Contact panel #3 -->
            <div class="col-sm-12 col-md-12 col-lg-6">
                <div class="cta__banner">
                    <h5 class="cta__title color-white">A Leading Developer Of A Grade
                        Commercial & Residential Projects</h5>
                    <p class="cta__desc color-gray">Today Promin has over 4,000 professionals on its payroll All Over
                        The
                        World.</p>
                    <a href="services.html" class="btn btn__primary btn__link color-white">
                        <span>Learn More</span> <i class="icon-arrow-right"></i>
                    </a>
                </div><!-- /.cta__banner -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.Contact Info -->


<section style="background-color: #1E1E1E;" class="banner-layout4 mt--150 pb-0">
    <div class="container-fluid col-padding-0">
        <div class="row">
            <div style="background-color: #1E1E1E;" class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                <div class="inner-padding ">
                    <div class="heading-layout2 heading-light mb-40">
                        <p class="heading__subtitle">ABOUT COMPANY</p>
                        <h2 class="heading__title">Unlocking Efficiency, Powered by Innovation</h2>
                        <h6 style="color:white;">Your Trusted Logistics Partner for Seamless Solutions Since 1995</h6>
                        <p class="heading__desc">"We provide efficient logistics solutions that leverage advanced
                            technology, delivering exceptional services and customized solutions to optimize supply
                            chain operations, reduce transportation and logistics costs, and ensure complete
                            transparency."</p>
                    </div><!-- /.heading -->
                    <div class="row fancybox-light">
                        <!-- fancybox item #1 -->
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="fancybox-item">
                                <div class="fancybox__icon">
                                    <i class="icon-welding"></i>
                                </div><!-- /.fancybox-icon -->
                                <div class="fancybox__content">
                                    <p class="fancybox__desc">D G Upali Ananda Siriwardhana</p>
                                    <p class="fancybox__desc">OFounder & Managing Director</p>
                                </div><!-- /.fancybox-content -->
                            </div><!-- /.fancybox-item -->
                        </div><!-- /.col-lg-6 -->
                        <!-- fancybox item #2 -->
                    </div><!-- /.row -->
                </div>
            </div><!-- /.col-xl-6 -->
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 background-banner">
                <div class="bg-img">
                    <img src="assets/images/banners/2.jpg" alt="banner">
                </div>
            </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.Banner layout 4 -->

<!-- =========================== 
      portfolio standard carousel
    ============================= -->
<section style="background-color: #1E1E1E;" class="portfolio-standard portfolio-standard-carousel pt-120 pb-60">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
                <div class="heading text-center mb-50">
                    <span class="heading__subtitle">
                        SPECIALISE IN THE TRANSPORTATION</span>
                    <h2 style="color: white;" class="heading__title">pecialist logistics services</h2>
                </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="slick-carousel"
                    data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows": false, "dots": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 2}}, {"breakpoint": 767, "settings": {"slidesToShow": 2}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
                    <!-- portfolio item #1 -->
                    <div class="portfolio-item">
                        <div class="portfolio__img">
                            <img src="assets/images/portfolio/grid/1.jpg" alt="portfolio img">
                        </div><!-- /.portfolio-img -->
                        <div class="portfolio__content">
                            <h4 class="portfolio__title"><a style="color: white;" href="#">Loading, Unloading, and
                                    Lifting Solutions</a>
                            </h4>
                            <p class="portfolio__desc">SERVICES FOR SAFE AND EFFICIENT CARGO HANDLING.</p>
                            <a style="background-color: #38b395;" href="#" class="btn btn__loadMore"><span>Explore
                                    More</span><i class="icon-arrow-right"></i></a>
                        </div><!-- /.portfolio-content -->
                    </div><!-- /.portfolio-item -->
                    <div class="portfolio-item">
                        <div class="portfolio__img">
                            <img src="assets/images/portfolio/grid/2.jpg" alt="portfolio img">
                        </div><!-- /.portfolio-img -->
                        <div class="portfolio__content">
                            <h4 class="portfolio__title"><a style="color: white;" href="#">Professional Installation of
                                    Large Machinery</a>
                            </h4>
                            <p class="portfolio__desc">PLACEMENT FOR COMMERCIAL AND INDUSTRIAL SETTINGS.</p>
                            <a style="background-color: #38b395;" href="#" class="btn btn__loadMore"><span>Explore
                                    More</span><i class="icon-arrow-right"></i></a>
                        </div><!-- /.portfolio-content -->
                    </div><!-- /.portfolio-item -->
                    <div class="portfolio-item">
                        <div class="portfolio__img">
                            <img src="assets/images/portfolio/grid/3.jpg" alt="portfolio img">
                        </div><!-- /.portfolio-img -->
                        <div class="portfolio__content">
                            <h4 class="portfolio__title"><a style="color: white;" href="#">High Value Cargo and
                                    Machinery Transportation</a>
                            </h4>
                            <p class="portfolio__desc">BEST PRACTICES FOR DELIVERY AND INSTALLATION.</p>
                            <a style="background-color: #38b395;" href="#" class="btn btn__loadMore"><span>Explore
                                    More</span><i class="icon-arrow-right"></i></a>
                        </div><!-- /.portfolio-content -->
                    </div><!-- /.portfolio-item -->
                </div><!-- /.slick-carousel -->
            </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.portfolio standard carousel -->
<!-- =========================
       Banner layout 2
      =========================== -->
<section style="background-color: #1E1E1E;" class="banner-layout2">
    <div style="height: 300px;" class="bg-img"><img src="assets/images/banners/3.jpg" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 text-center">
                <div class="heading-layout2 heading-light mb-50">
                    <h6 style="color: white;">GET IN TOUCH WITH US ANYTIME</h6>
                    <h2 class="heading__title ">Looking for the best
                        logistics transport & machinery placement Service?
                    </h2>
                    <a href="" class="btn btn__primary action__btn-request">
                        <span>Get A Quote</span><i class="icon-arrow-right"></i>
                    </a>
                </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.Banner layout 2 -->


<!-- ======================
      Blog carousel
    ========================= -->
<section style="background-color: #1E1E1E;" class="blog-carousel pt-0 pb-50 mt--200 z-index-2">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6">
                <div class="heading heading-layout3 mb-40">
                    <h6 style="color: white;">LATEST PROJECTS</h6>
                    <h2 style="color: white;" class="heading__title">Works across the SriLanka</h2>
                </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="slick-carousel"
                    data-slick='{"slidesToShow": 3, "slidesToScroll": 3, "arrows": true, "dots": false, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 2}}, {"breakpoint": 767, "settings": {"slidesToShow": 2}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
                    <!-- Blog Item #1 -->
                    <div class="blog-item">
                        <div class="blog__img">
                            <a href="#">
                                <img src="assets/images/blog/grid/1.jpg" alt="blog image">
                            </a>
                        </div><!-- /.blog-img -->
                        <div class="blog__content">
                            <div class="blog__meta">
                                <div class="blog__meta-cat">
                                    <a href="#">Oil & Gas</a><a href="#">Insights</a>
                                </div><!-- /.blog-meta-cat -->
                            </div><!-- /.blog-meta -->
                            <h4 class="blog__title"><a style="color: wheat;" href="#">Importers achieve cost savings
                                    through the First Sale
                                    rule!</a>
                            </h4>
                            <span class="blog__meta-date">Jan 20, 2020</span>
                            <p class="blog__desc">The trade war currently ensuing between the US and several nations
                                around the
                                globe, most fiercely with China, shows no signs of the first set of tariffs levied
                                against solar...
                            </p>
                            <a href="#" class="btn btn__secondary btn__link">
                                <span>Read More</span>
                                <i style="background-color:#38b395;" class="icon-arrow-right"></i>
                            </a>
                        </div><!-- /.blog-content -->
                    </div><!-- /.blog-item -->
                    <div class="blog-item">
                        <div class="blog__img">
                            <a href="#">
                                <img src="assets/images/blog/grid/1.jpg" alt="blog image">
                            </a>
                        </div><!-- /.blog-img -->
                        <div class="blog__content">
                            <div class="blog__meta">
                                <div class="blog__meta-cat">
                                    <a href="#">Oil & Gas</a><a href="#">Insights</a>
                                </div><!-- /.blog-meta-cat -->
                            </div><!-- /.blog-meta -->
                            <h4 class="blog__title"><a style="color: wheat;" href="#">Importers achieve cost savings
                                    through the First Sale
                                    rule!</a>
                            </h4>
                            <span class="blog__meta-date">Jan 20, 2020</span>
                            <p class="blog__desc">The trade war currently ensuing between the US and several nations
                                around the
                                globe, most fiercely with China, shows no signs of the first set of tariffs levied
                                against solar...
                            </p>
                            <a href="#" class="btn btn__secondary btn__link">
                                <span>Read More</span>
                                <i style="background-color:#38b395;" class="icon-arrow-right"></i>
                            </a>
                        </div><!-- /.blog-content -->
                    </div><!-- /.blog-item -->
                    <div class="blog-item">
                        <div class="blog__img">
                            <a href="#">
                                <img src="assets/images/blog/grid/1.jpg" alt="blog image">
                            </a>
                        </div><!-- /.blog-img -->
                        <div class="blog__content">
                            <div class="blog__meta">
                                <div class="blog__meta-cat">
                                    <a href="#">Oil & Gas</a><a href="#">Insights</a>
                                </div><!-- /.blog-meta-cat -->
                            </div><!-- /.blog-meta -->
                            <h4 class="blog__title"><a style="color: wheat;" href="#">Importers achieve cost savings
                                    through the First Sale
                                    rule!</a>
                            </h4>
                            <span class="blog__meta-date">Jan 20, 2020</span>
                            <p class="blog__desc">The trade war currently ensuing between the US and several nations
                                around the
                                globe, most fiercely with China, shows no signs of the first set of tariffs levied
                                against solar...
                            </p>
                            <a href="#" class="btn btn__secondary btn__link">
                                <span>Read More</span>
                                <i style="background-color:#38b395;" class="icon-arrow-right"></i>
                            </a>
                        </div><!-- /.blog-content -->
                    </div><!-- /.blog-item -->
                    <div class="blog-item">
                        <div class="blog__img">
                            <a href="#">
                                <img src="assets/images/blog/grid/1.jpg" alt="blog image">
                            </a>
                        </div><!-- /.blog-img -->
                        <div class="blog__content">
                            <div class="blog__meta">
                                <div class="blog__meta-cat">
                                    <a href="#">Oil & Gas</a><a href="#">Insights</a>
                                </div><!-- /.blog-meta-cat -->
                            </div><!-- /.blog-meta -->
                            <h4 class="blog__title"><a style="color: wheat;" href="#">Importers achieve cost savings
                                    through the First Sale
                                    rule!</a>
                            </h4>
                            <span class="blog__meta-date">Jan 20, 2020</span>
                            <p class="blog__desc">The trade war currently ensuing between the US and several nations
                                around the
                                globe, most fiercely with China, shows no signs of the first set of tariffs levied
                                against solar...
                            </p>
                            <a href="#" class="btn btn__secondary btn__link">
                                <span>Read More</span>
                                <i style="background-color:#38b395;" class="icon-arrow-right"></i>
                            </a>
                        </div><!-- /.blog-content -->
                    </div><!-- /.blog-item -->
                </div><!-- /.carousel -->
            </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.blog carousel -->

<?php include 'inc/footer.php'; ?>