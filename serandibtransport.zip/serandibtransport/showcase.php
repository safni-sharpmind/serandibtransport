<?php include ('inc/header.php'); ?>

<section class="page-title page-title-layout1 bg-overlay bg-overlay-2 bg-parallax">
    <div class="bg-img"><img src="assets/images/page-titles/1.jpg" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                <!-- <span class="pagetitle__subheading">World's Leading Industry Corporation!</span> -->
                <h1 class="pagetitle__heading">Showcase</h1>
                <!-- <a href="projects-grid.html" class="btn btn__white btn__bordered btn__icon">
                    <span>Latest Projects</span><i class="icon-arrow-right"></i>
                </a> -->
            </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.page-title -->


<section style="background-color: #1E1E1E;">
    <div class="container">
        <div class="heading text-center mb-50">
            <span class="heading__subtitle">
                INQUBE AT RANALA</span>
            <h6 style="color: white;">Unloading and placing chillers and AHU</h6>
        </div><!-- /.heading -->
        <div class="row mb-50">
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
        </div>



        <div class="heading text-center mb-50">
            <span class="heading__subtitle">
                606 THE ADDRESS</span>
            <h6 style="color: white;">Loading, Transporting, Unloading moving and placing 2
                Cummins generators with 640KVA from ground floor to 7th floor through the ramp and 2 cummins generator
                with 1250kva 85 feet above at 606</h6>
        </div><!-- /.heading -->
        <div class="row mb-50">
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
            <div class="col-md-3 mb-5">
                <img src="https://placehold.co/600x400" alt="">
            </div>
        </div>
    </div>
</section>

<?php include ('inc/footer.php'); ?>